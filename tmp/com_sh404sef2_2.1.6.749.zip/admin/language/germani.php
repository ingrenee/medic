<?php
/**
* @version $Id: germani.php 1018 2009-09-04 21:41:47Z silianacom-svn $
* german redirector for sh4040
* @package sh404 - sef urls for Joomla! OS CMS
* @subpackage languages
* @copyright (C) 2008 mic - michael [ http://www.joomx.com ]
* @info info@joomx.com http://www.joomx.com
* @license GNU/GPL License : http://www.gnu.org/copyleft/gpl.html
*/
defined( '_JEXEC' ) or die( 'No Direct Access' );

require_once( dirname( __FILE__ ).'/german.php' );
?>