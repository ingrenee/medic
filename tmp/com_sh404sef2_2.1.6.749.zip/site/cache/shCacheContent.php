<?php // shCache : URL cache file for sh404SEF
if (!defined('_VALID_MOS') && !defined('_JEXEC')) die('Direct Access to this location is not allowed.');
?>
